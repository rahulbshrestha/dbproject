# dbproject
Student Rating Service <br/>
(1) clamv still not working <br/>
(2) the second question wasn't clear <br/>
